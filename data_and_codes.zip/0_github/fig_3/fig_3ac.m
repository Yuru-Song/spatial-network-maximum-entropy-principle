clear all;
close all;
% not the EXACT way to plot figure 3a- 3c

% specify nodes and their locations, all in unit 1
[X,Y,Z] = meshgrid([.2, .5]);
num_node = numel(X);
node_loc  = [reshape(X,[1,num_node])', reshape(Y,[1, num_node])', reshape(Z,[1, num_node])'];

% other parameters for the random growth model
max_indeg = ones(1, num_node)*10; % maximum number of connections per node
max_outdeg = 10; % number of outgoing axons
link_range = 0.06; % node(sphere) radius
spatial_res = 0.01; % growth speed
max_time = 400; % total growth time
beta = 1; % probability of forming a connection

% run simulation
rand_growth_fix_degrees3(node_loc, max_outdeg, link_range, spatial_res, max_time,  max_indeg, beta);

