clear all;close all;

% figure 3 d through i

data_type = ["celegans_global"; "celegans_local"; "drosophila";...
    "mouse"; "macaque"; "human128";]
load("../data/MEP_data_1106");
for net_type = 2
    if net_type == 2
        load(['../data/celegans_local_all']);
        adj_grow = adj_ran_grow;
    else
        adj_grow = data.(data_type(net_type)).adj_grow;
        adj = data.(data_type(net_type)).adj;
        adj = adj + adj'>0;
        adj_ran = data.(data_type(net_type)).adj_ER;
        dis = data.(data_type(net_type)).dis;
    end
    
    con_dis = dis.*adj;
    con_dis_ran = dis.*adj_ran;
    con_dis_grow = dis.*adj_grow;
    [p, dcen] = hist(reshape(con_dis(find(con_dis > 0)), [prod(size(con_dis(find(con_dis > 0)))), 1]), 100);p = p/sum(p);
    [p_ran, dcen] = hist(reshape(con_dis_ran(find(con_dis_ran > 0)), [prod(size(con_dis_ran(find(con_dis_ran > 0)))), 1]), 100); p_ran = p_ran/sum(p_ran);
    [p_grow, dcen] = hist(reshape(con_dis_grow(find(con_dis_grow > 0)), [prod(size(con_dis_grow(find(con_dis_grow > 0)))), 1]), 100); p_grow = p_grow/sum(p_grow);
    figure(net_type);  
    set(gcf, 'Units', 'Normalized', 'OuterPosition', [.8, 0.64, .18, 0.25]);
    hold on;
    xticks([]);
    yticks([]);
    bar(dcen, p, 'FaceColor',[0.8 0.8 0.8],'EdgeColor','none');
    plot(dcen, p_grow, '-r');
    plot(dcen, p_ran, '--b');
end