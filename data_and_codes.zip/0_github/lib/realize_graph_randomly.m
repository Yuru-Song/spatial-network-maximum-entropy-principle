function [adj_pred, rate] = realize_graph_randomly(adj, dis)
node_num = size(adj, 1);
adj = adj >0;
adj_un = adj + adj' > 0;
seq_deg = degrees(adj_un);
available_node = 1: node_num;
adj_pred = zeros(node_num);
for lay_off_step = 1: node_num
    if numel(available_node) > 2
        source = available_node(1);
%         rng('shuffle');
%         source = available_node(randi( numel(available_node)));
         available_node = available_node(find(available_node ~= source));
        [sorted_seq_deg, ind] = sort(seq_deg(available_node), 'descend');
        target_num = seq_deg(source);
        adj_pred(source, available_node(ind(1: target_num))) = 1;
        seq_deg(source) = 0;
        seq_deg(available_node(ind(1: target_num))) = seq_deg(available_node(ind(1: target_num))) - 1;
    end
end
adj_pred = adj_pred + adj_pred';
[TP, TN, FP, FN] = recover_rate(adj_un, adj_pred);
rate = TP/sum(TP + FN);
