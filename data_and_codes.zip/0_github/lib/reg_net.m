clear all;clc;
% compute the lower bound of the entropy, i.e. the regular network's
% entropy


load('../data/MEP_data_1104.mat');
data_type = ["celegans_global"; "celegans_local"; "drosophila";...
    "mouse"; "macaque"; "human128"; "shmetro"; "USAir"];


for i = 1: 6
adj = data.(data_type(i)).adj;
adj = adj + adj'>0;
dis = data.(data_type(i)).dis;
ave_link_len = 1000;
    for init_node = 1: size(adj,1)
        [adj_reg, tmp_ave_link_len] = realize_reg_net(adj, dis, init_node);
        if tmp_ave_link_len < ave_link_len
            data.(data_type(i)).adj_reg = adj_reg;
            save('MEP_data_1104','data');
            save(['reg_net_',num2str(i)],'adj_reg');
        end
    end
end