function adj_ER = ER_graph(num_node, num_edge)
% INPUT:
%       num_node;
%       num_edge: of an undirected network, assumed as even
% OUTPUT:
%       adj_ER

num_edge_half = floor(num_edge*.5);
mask = ones(num_node);
ind = find(triu(mask) - eye(num_node));
sample_ind = datasample(ind, num_edge_half, 'Replace', false);
adj_ER = zeros(num_node);
adj_ER(ind2sub(size(adj_ER), sample_ind)) = 1;
adj_ER = adj_ER + adj_ER';

