function [entropy, mean_d, L] = correction_model(adj,adj_reg, dis, fig_option) 




adj = adj + adj'> 0;

bin_num = 100;
num_node = size(adj, 1);
num_link = sum(sum(adj))/2;
con_dis_true = adj.*dis;
[entropy_true,dcen] = distance_entropy(adj, dis, bin_num);
mean_d_true = mean(con_dis_true(find(con_dis_true>0)));
L_true = ave_path_length(adj);

%% get spatial regular network

% method 1
% [dis_sort, dis_ind] = sort(dis(find(dis>0)), 'ascend');
% dis_thrshld_reg = dis_sort(num_link * 2);
% adj_reg = dis < dis_thrshld_reg;
% adj_reg = adj_reg - diag(diag(adj_reg));

% method 2
% adj_reg = zeros(size(adj));
% k = floor(num_link * 2/num_node);
% 
% adj_reg = roughly_regular_spatial_network(dis, 67);



% %% correction
adj_pred = adj_reg;
% adj_TP = ((adj_pred == 1)&(adj == 1)).*dis;
% adj_TN = ((adj_pred == 0)&(adj == 0)).*dis;
adj_FP = ((adj_pred == 1)&(adj == 0)).*dis;
adj_FN = ((adj_pred == 0)&(adj == 1)).*dis;

entropy = [distance_entropy(adj_pred, dis, dcen)];
con_dis = adj_pred.*dis;
mean_d = [mean(con_dis(find(con_dis>0)))];
L = [ave_path_length(adj_pred.*dis*1e-5 + adj_pred*5e-3)];
C = [clust_coeff(adj_pred)];
while sum(sum(adj_FP)) && sum(sum(adj_FN)) >0
    ind_FP = find(adj_FP == min(adj_FP(find(adj_FP>0))));   
    [row_FP, col_FP] = ind2sub(num_node, ind_FP);
    ind_FN = find(adj_FN == min(adj_FN(find(adj_FN>0))));
    [row_FN, col_FN] = ind2sub(num_node, ind_FN);

    
    adj_pred(row_FP(1), col_FP(1)) = 0;
    adj_pred(row_FP(2), col_FP(2)) = 0;
    adj_pred(row_FN(1), col_FN(1)) = 1;
    adj_pred(row_FN(2), col_FN(2)) = 1;
    
%     adj_TP = ((adj_pred == 1)&(adj == 1)).*dis;
%     adj_TN = ((adj_pred == 0)&(adj == 0)).*dis;
    adj_FP = ((adj_pred == 1)&(adj == 0)).*dis;
    adj_FN = ((adj_pred == 0)&(adj == 1)).*dis;

    entropy = [entropy, distance_entropy(adj_pred, dis, dcen)];
    con_dis = adj_pred.*dis;
    mean_d = [mean_d, mean(con_dis(find(con_dis>0)))];
    L = [L, ave_path_length(adj_pred.*dis*1e-5 + adj_pred*5e-3)];
%     C = [C, clust_coeff(adj_pred)];
%     disp("***************************");
%     disp(entropy(end));
%     disp(mean_d);
%     disp(L(end));
    
    if fig_option > 0
        figure(1);
        set(gcf, 'Units', 'Normalized', 'OuterPosition', [0.5, 0.4, .5, .6]);
        subplot(231);
        imagesc(adj);
        title("data");
        subplot(232);
        imagesc(adj_pred);
        title("correction");
%         subplot(233);
%         plot(1:numel(C), C,'.r');
%         title('C');
        subplot(234);
        plot(1:numel(entropy), entropy,'.r');
        title('entropy');
        subplot(235);
        plot(1:numel(mean_d), mean_d, '.r');
        title('L');
        subplot(236);
        plot(1:numel(L), L, '.r');
%         ylim([1.2973, 1.3153]);
        title('ave. path length');
    end
    
%     pause;
end