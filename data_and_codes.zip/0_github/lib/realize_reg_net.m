function [adj_reg, ave_link_len] = realize_reg_net(adj, dis, init_node)
% Input: 
%   adj
%   dis
%   bin_num
%   init_node
% Output: 
%   adj_reg
% @ Nov-04-2019, Yuru Song

%parameters
node_num = size(adj, 1);


%turned into undirected graph first
adj = adj >0;
adj_un = adj + adj' > 0;
seq_deg = degrees(adj_un);

available_node = 1: node_num;
adj_reg = zeros(node_num);
for lay_off_step = 1: node_num
    if numel(available_node) > 2
        ave_link_len = 1000;
        if lay_off_step >1
            for try_step = 1: numel(available_node)
                try_adj_pred = adj_reg;
                try_source = available_node(try_step);
                try_available_node = available_node(find(available_node ~= try_source));
                try_seq_deg = seq_deg(try_available_node);
                try_target_num = seq_deg(try_source);
                [try_sorted_seq_deg, try_ind] = sort(try_seq_deg, 'descend');
                try_adj_pred(try_source, try_available_node(try_ind(1: try_target_num))) = 1;
                try_adj_pred = try_adj_pred + try_adj_pred'>0;
                try_con_dis = try_adj_pred.*dis;
                if  mean(try_con_dis(find(try_con_dis>0))) < ave_link_len
                    ave_link_len = mean(try_con_dis(find(try_con_dis>0)));
                    source = try_source;
                end
            end
        elseif lay_off_step == 1
            source = init_node;
        end
        available_node = available_node(find(available_node ~= source));
        [sorted_seq_deg, ind] = sort(seq_deg(available_node), 'descend');
        target_num = seq_deg(source);
        adj_reg(source, available_node(ind(1: target_num))) = 1;
        adj_reg(available_node(ind(1: target_num)), source) = 1;
        seq_deg(source) = 0;
        seq_deg(available_node(ind(1: target_num))) = seq_deg(available_node(ind(1: target_num))) - 1;        
    end
end
adj_reg = adj_reg + adj_reg'>0;
disp(['id  ',num2str(init_node)]);


