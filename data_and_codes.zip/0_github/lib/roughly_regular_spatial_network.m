function adj_reg = roughly_regular_spatial_network(dis, k)
dis_sorted = sort(dis,2);
adj_reg = dis < dis_sorted(:,k+2);
adj_reg = adj_reg - diag(diag(adj_reg));
adj_reg = adj_reg + adj_reg'>0;
sum(sum(adj_reg))