function [adj, edge_loc, in_deg] = rand_growth_fix_degrees2(node_loc, max_out_deg, link_range, spatial_res, max_time, max_indeg,beta)
node_num = size(node_loc, 1);
edge_direc = rand(node_num, max_out_deg, 1);
edge_direc(:, :, 1) = edge_direc(:, :, 1) * 2 * pi; %x-y plane angle
% edge_direc(:, :, 2) = (edge_direc(:, :, 2) - .5) * pi; % z axis angle
grow_index = ones(node_num, max_out_deg, 1); 
edge_loc = zeros(node_num, max_out_deg, 2);
adj = zeros(node_num);
for i = 1: max_out_deg
    edge_loc(:, i, :) = node_loc;
end
% node_dis = distance_matrix(node_loc);
for time = 1: max_time    
%        plot_network2(node_loc, edge_loc, link_range, time, grow_index);
%        pause();
%     if sum(sum(adj.*node_dis)) < ave_len * max_in_deg * node_num %&& sum(sum(adj)) < max_link + 1
        disp(time);
        % grow
        for node = 1: node_num
%             if sum(adj(node, :)) < max_outdeg(node)
                for i = 1: max_out_deg
                    if grow_index(node, i, 1) > 0
                        edge_loc(node, i, 1) = spatial_res * cos(edge_direc(node, i, 1))  + edge_loc(node, i, 1);
                        edge_loc(node, i, 2) = spatial_res * sin(edge_direc(node, i, 1)) + edge_loc(node, i, 2);  
%                         edge_loc(node, i, 3) = spatial_res * sin(edge_direc(node, i, 1)) + edge_loc(node, i, 3);  
                        % available node
                        in_deg = sum(adj, 1);
                        avail_node = find(in_deg < max_indeg);
%                         disp(size(avail_node))
%                         pause;
                        % detect link
                        for j = 1: numel(avail_node)
                            if sqrt((edge_loc(node, i, 1) - node_loc(avail_node(j), 1))^2 + (edge_loc(node, i, 2) - node_loc(avail_node(j), 2))^2)  < link_range && adj(node, avail_node(j))<1 && avail_node(j) ~= node 
                                if rand() < beta
                                    adj(node, avail_node(j)) = 1;
                                    adj(avail_node(j),node) = 1;
                                    grow_index(node, i, 1) = 0;
                                end
                            end
                        end
                    end
                end
%             end
%         end   
        end
%     if time == max_time
%         con_dis = adj.* distance_matrix(node_loc);
%         disp(['ave_length = ',num2str(mean(con_dis(find(con_dis>0))))]);
%         end
end
