clear all;close all;


data_name = ["celegans_global"; "celegans_local"; "drosophila";"mouse";"macaque";"human128";];
data_inset_op = [1, 1, 0, 0, 0, 0, 1, 1, 1];
data_path = '../data/';

for i = 1: 6
    load(strcat(data_path,'MEP_net_',data_name(i),'.mat'));
    optimize_pd(adj, dis, 30,1, data_inset_op(i),1,data_name(i));
    close all;
end

