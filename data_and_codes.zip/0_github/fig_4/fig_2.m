
clear all;
path_data = "../data/";
data_name = ["celegans_local";"drosophila-2";"mouse";"cocomac";"human";"USAir";"shmetro"];
path_fig =  "./";
for i = 1: numel(data_name)
    file_name = strcat(path_data, data_name(i), "_all.mat");
    load(convertStringsToChars(file_name));
    con_dis_true = (adj_true>0).*dis;
    [p_true, dcen] = hist(con_dis_true(find(con_dis_true>0)), 200);
    con_dis_pred = adj_pred.*dis;
    [p_pred, dcen] = hist(con_dis_pred(find(con_dis_pred>0)), dcen);
    con_dis_ran = adj_ran.*dis;
    [p_ran, dcen] = hist(con_dis_ran(find(con_dis_ran>0)), dcen);
    con_dis_pure_ran = adj_pure_ran.*dis;
    [p_pure_ran, dcen] = hist(con_dis_pure_ran(find(con_dis_pure_ran>0)), dcen);
    k_pred(i) = KLDiv(p_pred(find(p_true>0)),p_true(find(p_true>0)));
    k_ran(i) = KLDiv(p_ran(find(p_true>0)),p_true(find(p_true>0)));
    k_pure_ran(i) = KLDiv(p_pure_ran(find(p_true>0)),p_true(find(p_true>0)));
    r_pred(i) = recover_rate(adj_true, adj_pred);
    r_ran(i) = recover_rate(adj_true, adj_ran);
    r_pure_ran(i) = recover_rate(adj_true, adj_pure_ran);
    CC_true(i) = clust_coeff(adj_true);
    CC_pred(i) = clust_coeff(adj_pred);
    CC_ran(i) = clust_coeff(adj_ran);
    CC_pure_ran(i) = clust_coeff(adj_pure_ran);
    [Ci, Q_true(i)] = modularity_und(adj_true);
    [Ci, Q_pred(i)] = modularity_und(adj_pred);
    [Ci, Q_ran(i)] = modularity_und(adj_ran);
    [Ci, Q_pure_ran(i)] = modularity_und(adj_pure_ran);
    
end
xtickname = ["$\textit{C elegans} local$";"$\textit{Drosophila}$";"Mouse";"Macaque";"Human";"US Airport";"Shanghai Subway"];
figure(1);
set(gcf,'Units','Normalized','OuterPosition',[0.,0.7,.3,.3]);
b1 = bar(1./[k_pred; k_ran; k_pure_ran]');
color = brewermap(3,'GnBu');
b1(1).EdgeColor = 'none';
b1(2).EdgeColor = 'none';
b1(3).EdgeColor = 'none';
b1(1).FaceColor = color(1,:);
b1(2).FaceColor = color(2,:);
b1(3).FaceColor = color(3,:);
xticks([]);
legend('MEP','non-MEP','random');
saveas(1,convertStringsToChars(strcat(path_fig,"inverse_kl_div")),'epsc');
% xticklabels(xtickname,'Interpreter', 'LaTeX');
% xtickangle(45);

% color = [31, 119, 180;
%     255, 127, 14;
%     44, 160, 44]/255.;
figure(2);
set(gcf,'Units','Normalized','OuterPosition',[0.,0.4,.3,.3]);
b2 = bar([r_pred; r_ran; r_pure_ran]');
b2(1).EdgeColor = 'none';
b2(2).EdgeColor = 'none';
b2(3).EdgeColor = 'none';
b2(1).FaceColor = color(1,:);
b2(2).FaceColor = color(2,:);
b2(3).FaceColor = color(3,:);
saveas(2,convertStringsToChars(strcat(path_fig,"rate")),'epsc');

figure(3);
set(gcf,'Units','Normalized','OuterPosition',[0.5,0.7,.3,.3]);
b3 = bar([CC_pred./CC_true; CC_ran./CC_true; CC_pure_ran./CC_true]');
b3(1).EdgeColor = 'none';
b3(2).EdgeColor = 'none';
b3(3).EdgeColor = 'none';
b3(1).FaceColor = color(1,:);
b3(2).FaceColor = color(2,:);
b3(3).FaceColor = color(3,:);
xticks([]);
saveas(3,convertStringsToChars(strcat(path_fig,"clust_coeff")),'epsc');

figure(4);
set(gcf,'Units','Normalized','OuterPosition',[0.5,0.4,.3,.3]);
b4 = bar([Q_pred./Q_true; Q_ran./Q_true; Q_pure_ran./Q_true]');
b4(1).EdgeColor = 'none';
b4(2).EdgeColor = 'none';
b4(3).EdgeColor = 'none';
b4(1).FaceColor = color(1,:);
b4(2).FaceColor = color(2,:);
b4(3).FaceColor = color(3,:);
saveas(4,convertStringsToChars(strcat(path_fig,"modularity")),'epsc');

pause;
close all;
